Practica1
=========

Para usar el web server primero se utiliza el terminal y nos ubicamos en la ubicacion de la practica. Despues se compila el web server escribiendo make en el terminal. Despues para ejecutar el web server se escribe en el terminal ./webserver, con esto se activa el web server con la direccion ip 127.0.0.1 en el puerto 8080. Ahora para accesar al web server se escribe en el navegador web 127.0.0.1:8080. Con esto se muestra si existe la pagina o no.
