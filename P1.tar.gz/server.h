#ifndef _SERVER_H
#define _SERVER_H value

int startServer(const unsigned int port);

#endif
